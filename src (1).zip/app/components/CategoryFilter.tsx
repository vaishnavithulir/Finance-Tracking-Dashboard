import { Badge } from "./ui/badge";
import { ScrollArea } from "./ui/scroll-area";

export type TransactionCategory = 'all' | 'income' | 'expense' | 'food' | 'transport' | 'shopping' | 'bills' | 'entertainment' | 'health';

interface CategoryFilterProps {
  selectedCategory: TransactionCategory;
  onCategoryChange: (category: TransactionCategory) => void;
}

const categories: { label: string; value: TransactionCategory }[] = [
  { label: 'All', value: 'all' },
  { label: 'Income', value: 'income' },
  { label: 'Expense', value: 'expense' },
  { label: 'Food', value: 'food' },
  { label: 'Transport', value: 'transport' },
  { label: 'Shopping', value: 'shopping' },
  { label: 'Bills', value: 'bills' },
  { label: 'Entertainment', value: 'entertainment' },
  { label: 'Health', value: 'health' },
];

export function CategoryFilter({ selectedCategory, onCategoryChange }: CategoryFilterProps) {
  return (
    <ScrollArea className="w-full whitespace-nowrap">
      <div className="flex gap-2 pb-2">
        {categories.map((category) => (
          <Badge
            key={category.value}
            variant={selectedCategory === category.value ? 'default' : 'outline'}
            className="cursor-pointer transition-all hover:scale-105 active:scale-95 select-none"
            onClick={() => onCategoryChange(category.value)}
          >
            {category.label}
          </Badge>
        ))}
      </div>
    </ScrollArea>
  );
}
