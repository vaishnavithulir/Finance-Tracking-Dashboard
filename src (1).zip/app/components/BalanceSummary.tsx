import { Card } from "./ui/card";
import { TrendingUp, TrendingDown, Wallet } from "lucide-react";

interface BalanceSummaryProps {
  totalBalance: number;
  income: number;
  expenses: number;
}

export function BalanceSummary({ totalBalance, income, expenses }: BalanceSummaryProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  return (
    <Card className="p-6 bg-gradient-to-br from-blue-600 to-blue-700 text-white border-0 shadow-lg">
      <div className="flex items-center gap-2 mb-4 opacity-90">
        <Wallet className="size-5" />
        <span className="text-sm">Total Balance</span>
      </div>
      <div className="mb-6">
        <h2 className="text-4xl font-bold">{formatCurrency(totalBalance)}</h2>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
          <div className="flex items-center gap-2 mb-1">
            <TrendingUp className="size-4 text-green-300" />
            <span className="text-xs opacity-90">Income</span>
          </div>
          <p className="text-lg font-semibold">{formatCurrency(income)}</p>
        </div>
        <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
          <div className="flex items-center gap-2 mb-1">
            <TrendingDown className="size-4 text-red-300" />
            <span className="text-xs opacity-90">Expenses</span>
          </div>
          <p className="text-lg font-semibold">{formatCurrency(expenses)}</p>
        </div>
      </div>
    </Card>
  );
}
