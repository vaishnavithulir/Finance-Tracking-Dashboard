import { 
  ShoppingBag, 
  Coffee, 
  Car, 
  Home, 
  Film, 
  Heart, 
  TrendingUp, 
  DollarSign 
} from "lucide-react";
import { TransactionCategory } from "./CategoryFilter";
import { Badge } from "./ui/badge";

export interface Transaction {
  id: string;
  title: string;
  category: TransactionCategory;
  amount: number;
  date: string;
  type: 'income' | 'expense';
}

interface TransactionItemProps {
  transaction: Transaction;
}

const categoryIcons: Record<TransactionCategory, React.ComponentType<{ className?: string }>> = {
  all: DollarSign,
  income: TrendingUp,
  expense: DollarSign,
  food: Coffee,
  transport: Car,
  shopping: ShoppingBag,
  bills: Home,
  entertainment: Film,
  health: Heart,
};

const categoryColors: Record<TransactionCategory, string> = {
  all: 'bg-gray-100 text-gray-600',
  income: 'bg-green-100 text-green-600',
  expense: 'bg-red-100 text-red-600',
  food: 'bg-orange-100 text-orange-600',
  transport: 'bg-blue-100 text-blue-600',
  shopping: 'bg-purple-100 text-purple-600',
  bills: 'bg-yellow-100 text-yellow-600',
  entertainment: 'bg-pink-100 text-pink-600',
  health: 'bg-teal-100 text-teal-600',
};

export function TransactionItem({ transaction }: TransactionItemProps) {
  const Icon = categoryIcons[transaction.category];
  const colorClass = categoryColors[transaction.category];
  
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(Math.abs(amount));
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (date.toDateString() === today.toDateString()) {
      return 'Today';
    } else if (date.toDateString() === yesterday.toDateString()) {
      return 'Yesterday';
    } else {
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    }
  };

  return (
    <div className="flex items-center gap-4 p-4 hover:bg-gray-50 rounded-lg transition-colors active:bg-gray-100">
      <div className={`p-3 rounded-full ${colorClass}`}>
        <Icon className="size-5" />
      </div>
      <div className="flex-1 min-w-0">
        <h3 className="font-medium truncate">{transaction.title}</h3>
        <div className="flex items-center gap-2 mt-1">
          <Badge variant="secondary" className="text-xs capitalize">
            {transaction.category}
          </Badge>
          <span className="text-xs text-gray-500">{formatDate(transaction.date)}</span>
        </div>
      </div>
      <div className={`font-semibold ${transaction.type === 'income' ? 'text-green-600' : 'text-red-600'}`}>
        {transaction.type === 'income' ? '+' : '-'}{formatCurrency(transaction.amount)}
      </div>
    </div>
  );
}
