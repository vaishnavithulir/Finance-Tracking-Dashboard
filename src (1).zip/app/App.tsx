import { useState, useMemo } from "react";
import { BalanceSummary } from "./components/BalanceSummary";
import { CategoryFilter, TransactionCategory } from "./components/CategoryFilter";
import { TransactionList } from "./components/TransactionList";
import { AddTransactionDialog } from "./components/AddTransactionDialog";
import { Transaction } from "./components/TransactionItem";

// Mock data for demonstration
const initialTransactions: Transaction[] = [
  {
    id: '1',
    title: 'Salary Deposit',
    category: 'income',
    amount: 4500,
    date: new Date().toISOString(),
    type: 'income',
  },
  {
    id: '2',
    title: 'Grocery Shopping',
    category: 'food',
    amount: 127.50,
    date: new Date().toISOString(),
    type: 'expense',
  },
  {
    id: '3',
    title: 'Uber to Work',
    category: 'transport',
    amount: 15.75,
    date: new Date(Date.now() - 86400000).toISOString(), // Yesterday
    type: 'expense',
  },
  {
    id: '4',
    title: 'Netflix Subscription',
    category: 'entertainment',
    amount: 15.99,
    date: new Date(Date.now() - 86400000).toISOString(),
    type: 'expense',
  },
  {
    id: '5',
    title: 'New Headphones',
    category: 'shopping',
    amount: 89.99,
    date: new Date(Date.now() - 172800000).toISOString(), // 2 days ago
    type: 'expense',
  },
  {
    id: '6',
    title: 'Electricity Bill',
    category: 'bills',
    amount: 85.00,
    date: new Date(Date.now() - 259200000).toISOString(), // 3 days ago
    type: 'expense',
  },
  {
    id: '7',
    title: 'Coffee with Friends',
    category: 'food',
    amount: 24.50,
    date: new Date(Date.now() - 259200000).toISOString(),
    type: 'expense',
  },
  {
    id: '8',
    title: 'Freelance Project',
    category: 'income',
    amount: 850,
    date: new Date(Date.now() - 345600000).toISOString(), // 4 days ago
    type: 'income',
  },
];

export default function App() {
  const [transactions, setTransactions] = useState<Transaction[]>(initialTransactions);
  const [selectedCategory, setSelectedCategory] = useState<TransactionCategory>('all');

  // Filter transactions based on selected category
  const filteredTransactions = useMemo(() => {
    if (selectedCategory === 'all') {
      return transactions;
    }
    if (selectedCategory === 'income') {
      return transactions.filter(t => t.type === 'income');
    }
    if (selectedCategory === 'expense') {
      return transactions.filter(t => t.type === 'expense');
    }
    return transactions.filter(t => t.category === selectedCategory);
  }, [transactions, selectedCategory]);

  // Calculate totals
  const { totalBalance, income, expenses } = useMemo(() => {
    const income = transactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);
    const expenses = transactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);
    return {
      totalBalance: income - expenses,
      income,
      expenses,
    };
  }, [transactions]);

  const handleAddTransaction = (newTransaction: Omit<Transaction, 'id'>) => {
    const transaction: Transaction = {
      ...newTransaction,
      id: Date.now().toString(),
    };
    setTransactions([transaction, ...transactions]);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-40">
        <div className="max-w-md mx-auto px-4 py-4">
          <h1 className="text-xl font-semibold">Finance Tracker</h1>
          <p className="text-sm text-gray-600">Welcome back! 👋</p>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-md mx-auto px-4 py-6 space-y-6">
        {/* Balance Summary */}
        <BalanceSummary 
          totalBalance={totalBalance}
          income={income}
          expenses={expenses}
        />

        {/* Category Filter */}
        <div>
          <h2 className="text-sm font-medium text-gray-700 mb-3">Filter by Category</h2>
          <CategoryFilter 
            selectedCategory={selectedCategory}
            onCategoryChange={setSelectedCategory}
          />
        </div>

        {/* Recent Transactions */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-medium text-gray-700">Recent Transactions</h2>
            <span className="text-xs text-gray-500">
              {filteredTransactions.length} transaction{filteredTransactions.length !== 1 ? 's' : ''}
            </span>
          </div>
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <TransactionList transactions={filteredTransactions} />
          </div>
        </div>
      </main>

      {/* Add Transaction Button */}
      <AddTransactionDialog onAddTransaction={handleAddTransaction} />
    </div>
  );
}
